import torch.nn as nn
import torch

class HybridSN(nn.Module):
    def __init__(self, num_classes, input_bands, patch_size, self_attention=False):
        super(HybridSN, self).__init__()
        self.self_attention = self_attention

        # 3D 卷积块（对空间维度添加填充，保持空间尺寸）
        self.conv3d_1 = nn.Conv3d(1, 8, kernel_size=(7,3,3), stride=1, padding=0)
        self.conv3d_2 = nn.Conv3d(8, 16, kernel_size=(5,3,3), stride=1, padding=(0,1,1))  # 空间填充1
        self.conv3d_3 = nn.Conv3d(16, 32, kernel_size=(3,3,3), stride=1, padding=(0,1,1))  # 空间填充1

        self.relu = nn.ReLU(inplace=True)

        # 计算经过3D卷积后的输出尺寸（patch_size=8）
        # 空间尺寸: 8 -> 6 -> 6 -> 6
        # 波段维度: input_bands -> input_bands-6 -> input_bands-10 -> input_bands-12
        self.final_3d_channels = 32
        self.final_spectral = input_bands - 12
        self.final_h = 6
        self.final_w = 6

        self.conv2d_in_channels = self.final_3d_channels * self.final_spectral

        # 2D 卷积块
        self.conv2d = nn.Conv2d(self.conv2d_in_channels, 64, kernel_size=3, stride=1, padding=0)
        self.relu2 = nn.ReLU(inplace=True)

        # 全连接层输入尺寸
        fc_h = self.final_h - 2  # 6 -> 4
        fc_w = self.final_w - 2
        self.fc_input_size = 64 * fc_h * fc_w

        self.classifier = nn.Sequential(
            nn.Linear(self.fc_input_size, 256),
            nn.Dropout(p=0.4),
            nn.Linear(256, 128),
            nn.Dropout(p=0.4),
            nn.Linear(128, num_classes)
        )

    def forward(self, x):
        x = self.relu(self.conv3d_1(x))
        x = self.relu(self.conv3d_2(x))
        x = self.relu(self.conv3d_3(x))

        b, c, d, h, w = x.shape
        x = x.contiguous().view(b, c * d, h, w)

        if self.self_attention:
            pass

        x = self.relu2(self.conv2d(x))

        if self.self_attention:
            pass

        x = x.view(b, -1)
        x = self.classifier(x)
        return x


def hybridsn(dataset, patch_size, bands=None):
    if bands is None:
        raise ValueError("bands (num_bands) must be provided for HybridSN.")
    num_classes_map = {
        'sa': 16,
        'ip': 16,
        'whulk': 9,
        'botswana': 14,
        # 可根据需要添加更多数据集
    }
    num_classes = num_classes_map.get(dataset, 16)
    return HybridSN(num_classes, input_bands=bands, patch_size=patch_size)