import torch
import torch.nn as nn
from torch.nn import init

class CNN2D(nn.Module):
    """
    修复版：适配小patch_size (8/12)，解决尺寸过小+初始化顺序bug
    """
    @staticmethod
    def weight_init(m):
        if isinstance(m, nn.Linear) or isinstance(m, nn.Conv2d):
            init.kaiming_normal_(m.weight)
            init.zeros_(m.bias)

    def __init__(self, in_channels, n_classes, patch_size):
        super().__init__()
        self.patch_size = patch_size

        # 🔥 第一步：先定义所有层（必须先定义，再计算尺寸）
        self.conv_1 = nn.Conv2d(in_channels, 256, 3, padding=1)
        self.conv_2 = nn.Conv2d(256, 512, 3, padding=1)
        self.mp = nn.MaxPool2d(2)
        self.relu = nn.ReLU(inplace=True)

        # 🔥 第二步：再计算全连接层输入维度
        conv_out_size = self._calc_conv_out_size()
        self.fc_1 = nn.Linear(conv_out_size, 128)
        self.fc_2 = nn.Linear(128, n_classes)

        # 权重初始化
        self.apply(self.weight_init)

    def _calc_conv_out_size(self):
        """模拟前向，自动计算特征图尺寸"""
        with torch.no_grad():
            x = torch.randn(1, self.conv_1.in_channels, self.patch_size, self.patch_size)
            x = self.conv_1(x)
            if x.shape[-1] >= 2:
                x = self.mp(x)
            x = self.relu(x)

            x = self.conv_2(x)
            if x.shape[-1] >= 2:
                x = self.mp(x)
            x = self.relu(x)
            return x.numel()

    def forward(self, x):
        # 输入维度: [B, 1, C, H, W] → 压缩为 [B, C, H, W]
        x = x.squeeze(1)

        # 第一层
        x = self.conv_1(x)
        if x.shape[-1] >= 2:
            x = self.mp(x)
        x = self.relu(x)

        # 第二层
        x = self.conv_2(x)
        if x.shape[-1] >= 2:
            x = self.mp(x)
        x = self.relu(x)

        # 全连接
        x = torch.flatten(x, 1)
        x = self.fc_1(x)
        x = self.relu(x)
        x = self.fc_2(x)
        return x

def cnn2d(dataset, patch_size):
    model = None
    if dataset == 'sa':
        model = CNN2D(in_channels=204, n_classes=16, patch_size=patch_size)
    elif dataset == 'ip':
        model = CNN2D(in_channels=200, n_classes=16, patch_size=patch_size)
    elif dataset == 'whulk':
        model = CNN2D(in_channels=270, n_classes=9, patch_size=patch_size)
    elif dataset == 'botswana':
        model = CNN2D(in_channels=145, n_classes=14, patch_size=patch_size)
    elif dataset == 'flt':
        model = CNN2D(in_channels=80, n_classes=10, patch_size=patch_size)
    return model

# 测试代码
if __name__ == '__main__':
    test_input = torch.randn(1, 1, 200, 8, 8)
    net = cnn2d('ip', patch_size=8)
    out = net(test_input)
    print("输入shape:", test_input.shape)
    print("输出shape:", out.shape)