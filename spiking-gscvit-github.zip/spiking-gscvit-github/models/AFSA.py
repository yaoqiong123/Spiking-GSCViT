import torch
import torch.nn as nn
import torch.cuda
from models.Reconv import ReParameterizedRefocusingConv
from models.BP import Surrogate_BP_Function
from models.SSA import SSA


class AFSA(nn.Module):
    def __init__(self, num_steps, leak_mem, img_size, num_cls, input_dim, threshold=0.5):
        super(AFSA, self).__init__()
        self.threshold = threshold
        self.img_size = img_size
        self.num_cls = num_cls
        self.num_steps = num_steps
        self.spike_fn = Surrogate_BP_Function.apply
        self.leak_mem = leak_mem
        bias_flag = False

        self.conv1 = ReParameterizedRefocusingConv(input_dim, 64, kernel_size=7, stride=1, padding=3, bias=bias_flag)
        self.conv2 = ReParameterizedRefocusingConv(64, 64, kernel_size=7, stride=1, padding=3, bias=bias_flag)
        self.ssa1 = SSA(dim=64, num_heads=8)
        self.conv3 = ReParameterizedRefocusingConv(64, 128, kernel_size=7, stride=1, padding=3, bias=bias_flag)
        self.pool1 = nn.AvgPool2d(kernel_size=2)
        self.conv4 = ReParameterizedRefocusingConv(128, 192, kernel_size=5, stride=1, padding=2, bias=bias_flag)
        self.conv5 = ReParameterizedRefocusingConv(192, 192, kernel_size=3, stride=1, padding=1, bias=bias_flag)
        self.ssa2 = SSA(dim=192, num_heads=12)
        self.conv6 = ReParameterizedRefocusingConv(192, 256, kernel_size=3, stride=1, padding=1, bias=bias_flag)
        self.pool2 = nn.AvgPool2d(kernel_size=2)

        # 计算经过两次池化后的特征图空间尺寸
        final_size = img_size // 4
        self.fc1 = nn.Linear(256 * final_size * final_size, self.num_cls, bias=False)

        self.conv_list = [self.conv1, self.conv2, self.conv3, self.conv4, self.conv5, self.conv6]

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                m.threshold = self.threshold
                torch.nn.init.xavier_uniform_(m.weight, gain=5)
            elif isinstance(m, nn.Linear):
                m.threshold = self.threshold
                torch.nn.init.xavier_uniform_(m.weight, gain=5)
        for conv in self.conv_list:
            conv.threshold = self.threshold

    def forward(self, input, return_spikes=False):
        batch_size = input.size(0)
        mem_conv1 = torch.zeros(batch_size, 64, self.img_size, self.img_size).cuda()
        mem_conv2 = torch.zeros(batch_size, 64, self.img_size, self.img_size).cuda()
        mem_conv3 = torch.zeros(batch_size, 128, self.img_size, self.img_size).cuda()
        mem_conv4 = torch.zeros(batch_size, 192, self.img_size // 2, self.img_size // 2).cuda()
        mem_conv5 = torch.zeros(batch_size, 192, self.img_size // 2, self.img_size // 2).cuda()
        mem_conv6 = torch.zeros(batch_size, 256, self.img_size // 2, self.img_size // 2).cuda()
        mem_fc1 = torch.zeros(batch_size, self.num_cls).cuda()
        mem_conv_list = [mem_conv1, mem_conv2, mem_conv3, mem_conv4, mem_conv5, mem_conv6]
        static_input1 = self.conv1(input)

        total_spikes = 0  # 用于累计脉冲计数

        for t in range(self.num_steps):
            # conv1
            mem_conv_list[0] = self.leak_mem * mem_conv_list[0] + (1 - self.leak_mem) * static_input1
            mem_thr = mem_conv_list[0] - self.conv_list[0].threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[0]).cuda()
            rst[mem_thr > 0] = self.conv_list[0].threshold
            mem_conv_list[0] = mem_conv_list[0] - rst
            out_prev = out.clone()

            # conv2
            mem_conv_list[1] = self.leak_mem * mem_conv_list[1] + (1 - self.leak_mem) * self.conv2(out_prev)
            mem_thr = mem_conv_list[1] - self.conv2.threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[1]).cuda()
            rst[mem_thr > 0] = self.conv2.threshold
            mem_conv_list[1] = mem_conv_list[1] - rst
            out_prev = out.clone()

            # SSA1
            out_prev = out_prev.reshape(batch_size, -1, 64)
            out_prev = self.ssa1(out_prev)
            out_prev = out.clone()

            # conv3
            mem_conv_list[2] = self.leak_mem * mem_conv_list[2] + (1 - self.leak_mem) * self.conv3(out_prev)
            mem_thr = mem_conv_list[2] - self.conv3.threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[2]).cuda()
            rst[mem_thr > 0] = self.conv3.threshold
            mem_conv_list[2] = mem_conv_list[2] - rst
            out_prev = out.clone()

            # pool1
            out_prev = self.pool1(out_prev)

            # conv4
            mem_conv_list[3] = self.leak_mem * mem_conv_list[3] + (1 - self.leak_mem) * self.conv4(out_prev)
            mem_thr = mem_conv_list[3] - self.conv4.threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[3]).cuda()
            rst[mem_thr > 0] = self.conv4.threshold  # 修正：使用 conv4.threshold
            mem_conv_list[3] = mem_conv_list[3] - rst
            out_prev = out.clone()

            # conv5
            mem_conv_list[4] = self.leak_mem * mem_conv_list[4] + (1 - self.leak_mem) * self.conv5(out_prev)
            mem_thr = mem_conv_list[4] - self.conv5.threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[4]).cuda()
            rst[mem_thr > 0] = self.conv5.threshold
            mem_conv_list[4] = mem_conv_list[4] - rst
            out_prev = out.clone()

            # SSA2
            out_prev = out_prev.reshape(batch_size, -1, 192)
            out_prev = self.ssa2(out_prev)
            out_prev = out.clone()

            # conv6
            mem_conv_list[5] = self.leak_mem * mem_conv_list[5] + (1 - self.leak_mem) * self.conv6(out_prev)
            mem_thr = mem_conv_list[5] - self.conv6.threshold
            out = self.spike_fn(mem_thr)
            if return_spikes:
                total_spikes += out.sum().item()
            rst = torch.zeros_like(mem_conv_list[5]).cuda()
            rst[mem_thr > 0] = self.conv6.threshold
            mem_conv_list[5] = mem_conv_list[5] - rst
            out_prev = out.clone()

            # pool2
            out_prev = self.pool2(out_prev)
            out_prev = out_prev.reshape(batch_size, -1)
            mem_fc1 = mem_fc1 + self.fc1(out_prev)

        out_voltage = mem_fc1 / self.num_steps
        if return_spikes:
            return out_voltage, total_spikes
        else:
            return out_voltage