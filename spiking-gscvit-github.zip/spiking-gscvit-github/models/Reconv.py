import torch
import torch.nn as nn
import torch.cuda
class ReParameterizedRefocusingConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, bias=False):
        super(ReParameterizedRefocusingConv, self).__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, bias=bias)
        self.bn = nn.BatchNorm2d(out_channels)
        self.refocusing = nn.Parameter(torch.randn(1, out_channels, 1, 1) * 0.85 + 1)#可以替换

    def forward(self, x):
        x = self.conv(x)
        #print(f"conv输出形状: {x.shape}")
        x = self.bn(x)
        #print(f"bn输出形状: {x.shape}")
        refocused_features = x * self.refocusing
        return refocused_features
