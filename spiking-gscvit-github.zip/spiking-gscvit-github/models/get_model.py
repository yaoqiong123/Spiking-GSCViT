from .cnn2d import cnn2d
from .sprn import SPRN
from .cnn3d import cnn3d
from .hybridsn import hybridsn
from .spectralformer import spectralformer
from .ssftt import ssftt
from .gaht import gaht
from .gscvit import gscvit
from .morphFormer import morphFormer
from .caevt import caevt
from .snn_gscvit import snn_gscvit_spiking
from .snn_gscvit_fully_binary import snn_gscvit_fully_binary
from .snn_gscvit_pre import snn_gscvit_spiking_pre
from .snn_gscvit_with_pwsa import snn_gscvit_with_pwsa

from .AFSA import AFSA
from .TGRS import TGRS
def get_model(model_name, dataset_name, patch_size,**kwargs):
    if model_name == 'cnn2d':
        model = cnn2d(dataset=dataset_name, patch_size=patch_size)

    elif model_name == 'sprn':
        model = SPRN(dataset=dataset_name)

    elif model_name == 'cnn3d':
        model = cnn3d(dataset_name, patch_size)

    elif model_name == 'hybridsn':
        bands = kwargs.get('num_bands')
        if bands is None:
            raise ValueError("num_bands must be provided for hybridsn.")
        model = hybridsn(dataset_name, patch_size, bands=bands)
    elif model_name == 'spectralformer':
        model = spectralformer(dataset_name, patch_size)

    elif model_name == 'ssftt':
        model = ssftt(dataset_name, patch_size)

    elif model_name == 'gaht':
        model = gaht(dataset_name, patch_size)

    elif model_name == 'morphFormer':
        model = morphFormer(16, 80, 10, False, 8)

    elif model_name == 'gscvit':
        model = gscvit(dataset_name)
    elif model_name == 'snn_gscvit_spiking':
        num_bands = kwargs.get('num_bands')
        if num_bands is None:
            raise ValueError("For snn_gscvit_spiking, num_bands must be provided.")
        T = kwargs.get('T', 1)
        threshold = kwargs.get('threshold', 0.2)  # 从外部传入
        tau = kwargs.get('tau', 2.0)  # 从外部传入（或使用 leak_mem 转换）
        # 注意：snn_gscvit 使用 lif_tau 而非 leak_mem，这里将 leak_mem 转换为 tau
        # 如果同时传入 leak_mem，优先使用 leak_mem 计算 tau
        #leak_mem = kwargs.get('leak_mem')
        #if leak_mem is not None:
        #    tau = 1.0 / (1.0 - leak_mem) if leak_mem != 1 else float('inf')
        model = snn_gscvit_spiking(
            dataset_name,
            T=T,
            lif_threshold=threshold,
            lif_tau=tau,
            accum_mode='mean',
            input_channels=num_bands
        )

    elif model_name == 'snn_gscvit_spiking_pre':
        num_bands = kwargs.get('num_bands')
        if num_bands is None:
            raise ValueError("For snn_gscvit_spiking_pre, num_bands must be provided.")
        T = kwargs.get('T', 1)
        threshold = kwargs.get('threshold', 0.2)
        tau = kwargs.get('tau', 2.0)
        model = snn_gscvit_spiking_pre(
            dataset_name,
            T=T,
            lif_threshold=threshold,
            lif_tau=tau,
            accum_mode='mean',
            input_channels=num_bands
        )
    # 在 get_model 函数中添加：
    elif model_name == 'snn_gscvit_fully_binary':
        num_bands = kwargs.get('num_bands')
        if num_bands is None:
            raise ValueError("num_bands must be provided.")
        T = kwargs.get('T', 1)
        threshold = kwargs.get('threshold', 0.2)
        tau = kwargs.get('tau', 2.0)

        model = snn_gscvit_fully_binary(
            dataset_name,
            T=T,
            lif_threshold=threshold,
            lif_tau=tau,
            accum_mode='mean',
            input_channels=num_bands,
            use_pwc=kwargs.get('use_pwc', True)
        )

    elif model_name == 'snn_gscvit_with_pwsa':
        num_bands = kwargs.get('num_bands')
        if num_bands is None:
            raise ValueError("num_bands must be provided.")
        T = kwargs.get('T', 1)
        threshold = kwargs.get('threshold', 0.2)
        tau = kwargs.get('tau', 2.0)

        model = snn_gscvit_with_pwsa(
            dataset_name,
            T=T,
            lif_threshold=threshold,
            lif_tau=tau,
            accum_mode='mean',
            input_channels=num_bands,
            use_pwc=kwargs.get('use_pwc', True)
        )
    elif model_name == 'afsa':

        num_classes = kwargs.get('num_classes')
        num_bands = kwargs.get('num_bands')
        T = kwargs.get('T', 32)  # 从外部传入 T，默认 32
        leak_mem = kwargs.get('leak_mem', 0.7)  # 从外部传入 leak_mem，默认 0.5
        threshold = kwargs.get('threshold', 0.7)  # 从外部传入 threshold，默认 0.2
        model = AFSA(
            num_steps=T,
            leak_mem=leak_mem,
            img_size=patch_size,
            num_cls=num_classes,
            input_dim=num_bands,
            threshold=threshold  # 需在 AFSA 类中添加该参数
        )
    elif model_name == 'TGRS':
        num_classes = kwargs.get('num_classes')
        num_bands = kwargs.get('num_bands')
        T = kwargs.get('T', 2)  # 默认 2
        leak_mem = kwargs.get('leak_mem', 0.5)  # 默认 0.5
        threshold = kwargs.get('threshold', 0.2)  # 默认 0.2
        model = TGRS(
            num_steps=T,
            leak_mem=leak_mem,
            img_size=patch_size,
            num_cls=num_classes,
            input_dim=num_bands,
            threshold=threshold  # 需在 TGRS 类中添加该参数
        )

    elif model_name == 'caevt':
        model = caevt(dataset_name)

    else:
        raise KeyError("{} model is not supported yet".format(model_name))

    return model

