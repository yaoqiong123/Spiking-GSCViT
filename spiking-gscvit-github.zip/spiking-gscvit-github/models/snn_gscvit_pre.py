# 改进版 SNN-GSCViT (v6)
# 主要改进：
# 1. Transformer 内部使用膜电位传递，不再强制脉冲化
# 2. 简化 GSSA：仅保留组内自注意力 + 轻量跨组交互
# 3. 合并 LIF 层，减少计算开销
# 4. 注意力温度缩放 + dropout
# 5. 默认使用改进版，无需额外参数

import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
from einops import rearrange, repeat
from einops.layers.torch import Reduce
from thop import profile
from timm.models.vision_transformer import _cfg

# -------------------- 加速版 LIF 神经元 --------------------
class LIFSpike(nn.Module):
    __constants__ = ['tau', 'threshold', 'decay', 'return_spike']
    def __init__(self, tau=2.0, threshold=0.5, surrogate_grad='fast_sigmoid', return_spike=False):
        super().__init__()
        self.tau = tau
        self.threshold = threshold
        self.surrogate_grad = surrogate_grad
        self.decay = 1.0 / tau
        self.return_spike = return_spike
        self.membrane = None
        self.spike = None

    def forward(self, x):
        if self.membrane is None:
            self.membrane = torch.zeros_like(x)
            self.spike = torch.zeros_like(x)

        self.membrane = self.membrane * (1 - self.decay) + x
        spike = (self.membrane >= self.threshold).float()
        if self.training:
            if self.surrogate_grad == 'sigmoid':
                sig = torch.sigmoid(self.membrane - self.threshold)
                grad = sig * (1 - sig)
            else:  # fast_sigmoid
                grad = torch.clamp(1 - torch.abs(self.membrane - self.threshold) / 0.5, min=0, max=1)
            spike = spike + (self.membrane - self.threshold) * grad.detach()
        else:
            spike = spike.detach()

        self.membrane = self.membrane - spike.detach() * self.threshold
        self.spike = spike

        if self.return_spike:
            return spike
        else:
            return self.membrane

    def reset(self):
        self.membrane = None
        self.spike = None


def cast_tuple(val, length=1):
    return val if isinstance(val, tuple) else ((val,) * length)


class ChanLayerNorm(nn.Module):
    def __init__(self, dim, eps=1e-5):
        super().__init__()
        self.eps = eps
        self.g = nn.Parameter(torch.ones(1, dim, 1, 1))
        self.b = nn.Parameter(torch.zeros(1, dim, 1, 1))

    def forward(self, x):
        var = torch.var(x, dim=1, unbiased=False, keepdim=True)
        mean = torch.mean(x, dim=1, keepdim=True)
        return (x - mean) / (var + self.eps).sqrt() * self.g + self.b


# -------------------- GSC 模块（改进版：合并 LIF）--------------------
class SNNGSC(nn.Module):
    def __init__(self, dim_in, dim_out, padding=1, num_groups=8,
                 lif_threshold=0.5, lif_tau=2.0, surrogate_grad='fast_sigmoid'):
        super().__init__()
        self.gpwc = nn.Conv2d(dim_in, dim_out, groups=num_groups, kernel_size=1)
        self.gc = nn.Conv2d(dim_out, dim_out, kernel_size=3, groups=num_groups, padding=padding, stride=1)
        self.bn1 = nn.BatchNorm2d(dim_out)
        self.bn2 = nn.BatchNorm2d(dim_out)
        self.lif = LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False)

    def forward(self, x):
        x = self.gpwc(x)
        x = self.bn1(x)
        x = self.gc(x)
        x = self.bn2(x)
        x = self.lif(x)
        return x

    def reset(self):
        self.lif.reset()


# -------------------- 简化的脉冲自注意力（仅组内 + 轻量跨组）--------------------
class SimplifiedSpikingGSA(nn.Module):
    def __init__(self, dim, heads=8, group_size=4, dropout=0.,
                 lif_threshold=0.5, lif_tau=2.0, surrogate_grad='fast_sigmoid'):
        super().__init__()
        self.dim = dim
        self.heads = heads
        self.group_size = group_size
        self.inner_dim = dim
        self.dim_head = dim // heads
        assert dim % heads == 0, "dim must be divisible by heads"

        self.to_qkv = nn.Linear(dim, self.inner_dim * 3, bias=False)
        self.temperature = nn.Parameter(torch.ones(1) * 0.1)
        self.attend = nn.Softmax(dim=-1)
        self.dropout = nn.Dropout(dropout) if dropout > 0 else nn.Identity()

        self.group_pool = nn.AdaptiveAvgPool2d(1)
        self.group_fc = nn.Linear(dim, dim)
        self.group_lif = LIFSpike(tau=lif_tau, threshold=lif_threshold,
                                  surrogate_grad=surrogate_grad, return_spike=False)

    def forward(self, x):
        b, c, h, w = x.shape
        g = self.group_size
        hg, wg = h // g, w // g
        x_reshape = rearrange(x, 'b c (hg g1) (wg g2) -> b (hg wg) c (g1 g2)', g1=g, g2=g)
        ng = hg * wg
        x_seq = x_reshape.transpose(2, 3)  # (b, ng, g*g, c)

        qkv = self.to_qkv(x_seq)
        q, k, v = torch.chunk(qkv, 3, dim=-1)

        q = q.view(b, ng, -1, self.heads, self.dim_head).transpose(2, 3)
        k = k.view(b, ng, -1, self.heads, self.dim_head).transpose(2, 3)
        v = v.view(b, ng, -1, self.heads, self.dim_head).transpose(2, 3)

        attn = torch.einsum('b n h i d, b n h j d -> b n h i j', q, k) / (self.dim_head ** 0.5)
        attn = attn * self.temperature
        attn = self.attend(attn)
        attn = self.dropout(attn)

        out = torch.einsum('b n h i j, b n h j d -> b n h i d', attn, v)
        out = out.transpose(2, 3).contiguous().view(b, ng, -1, c)

        group_token = out.mean(dim=2)
        group_feat = group_token.transpose(1, 2).view(b, c, hg, wg)
        global_desc = self.group_pool(group_feat).view(b, c)
        global_bias = self.group_fc(global_desc).view(b, c, 1, 1)
        global_bias = self.group_lif(global_bias)

        out_feat = out.transpose(2, 3).reshape(b, ng, c, g, g)
        out_feat = rearrange(out_feat, 'b (hg wg) c g1 g2 -> b c (hg g1) (wg g2)', hg=hg, wg=wg)
        out_feat = out_feat + global_bias
        return out_feat

    def reset(self):
        self.group_lif.reset()


# -------------------- 改进后的 Transformer 块（膜电位传递）--------------------
class ImprovedSNNTransformer(nn.Module):
    def __init__(self, dim, depth, heads=8, group_size=4, dropout=0., norm_output=True,
                 lif_threshold=0.5, lif_tau=2.0, surrogate_grad='fast_sigmoid'):
        super().__init__()
        self.depth = depth
        self.layers = nn.ModuleList([
            SimplifiedSpikingGSA(dim, heads=heads, group_size=group_size, dropout=dropout,
                                 lif_threshold=lif_threshold, lif_tau=lif_tau, surrogate_grad=surrogate_grad)
            for _ in range(depth)
        ])
        self.norm = ChanLayerNorm(dim) if norm_output else nn.Identity()

    def forward(self, x):
        for attn in self.layers:
            x = attn(x)
        return self.norm(x)

    def reset(self):
        for attn in self.layers:
            attn.reset()


# -------------------- 主模型 SNNGSCViTImproved --------------------
class SNNGSCViTImproved(nn.Module):
    def __init__(
            self,
            *,
            num_classes,
            depth,
            heads,
            group_spatial_size,
            dropout=0.1,
            padding,
            dims,
            num_groups,
            T=8,
            lif_threshold=0.5,
            lif_tau=2.0,
            surrogate_grad='fast_sigmoid',
            accum_mode='sum',
            use_dropout=True,
            dropout_rate=2.0,
            use_pwc=True,
    ):
        super().__init__()
        self.config = {
            'num_classes': num_classes,
            'depth': depth,
            'heads': heads,
            'group_spatial_size': group_spatial_size,
            'dropout': dropout,
            'padding': padding,
            'dims': dims,
            'num_groups': num_groups,
            'T': T,
            'lif_threshold': lif_threshold,
            'lif_tau': lif_tau,
            'surrogate_grad': surrogate_grad,
            'accum_mode': accum_mode,
            'use_dropout': use_dropout,
            'dropout_rate': dropout_rate,
            'use_pwc': use_pwc,
        }
        self.T = T
        self.accum_mode = accum_mode
        num_stages = len(depth)
        dim_pairs = tuple(zip(dims[:-1], dims[1:]))
        hyperparams_per_stage = [heads]
        hyperparams_per_stage = list(map(partial(cast_tuple, length=num_stages), hyperparams_per_stage))

        self.layers_trans = nn.ModuleList([])
        for ind, ((layer_dim_in, layer_dim), layer_depth, layer_heads, p, num_group, g_size) in enumerate(
                zip(dim_pairs, depth, *hyperparams_per_stage, padding, num_groups, group_spatial_size)):
            is_last = ind == (num_stages - 1)

            if use_pwc:
                mlp_or_pwc = nn.Conv2d(layer_dim, layer_dim, 1)
            else:
                expand = 4
                mlp_or_pwc = nn.Sequential(
                    nn.Conv2d(layer_dim, layer_dim * expand, 1),
                    nn.BatchNorm2d(layer_dim * expand),
                    LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False),
                    nn.Conv2d(layer_dim * expand, layer_dim, 1),
                    nn.BatchNorm2d(layer_dim)
                )

            self.layers_trans.append(nn.ModuleList([
                SNNGSC(layer_dim_in, layer_dim, p, num_group,
                       lif_threshold=lif_threshold, lif_tau=lif_tau, surrogate_grad=surrogate_grad),
                ImprovedSNNTransformer(dim=layer_dim, depth=layer_depth, heads=layer_heads,
                                       group_size=g_size, dropout=dropout, norm_output=not is_last,
                                       lif_threshold=lif_threshold, lif_tau=lif_tau, surrogate_grad=surrogate_grad),
                nn.BatchNorm2d(layer_dim),
                mlp_or_pwc,
                LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False)
            ]))

        self.conv_last = nn.Sequential(
            nn.Conv2d(dims[-1], dims[-1] * 2, 3, padding=1),
            nn.BatchNorm2d(dims[-1] * 2),
            LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False),
            nn.Conv2d(dims[-1] * 2, dims[-1], 1)
        )
        self.gap = Reduce('b d h w -> b d', 'mean')
        self.norm = nn.LayerNorm(dims[-1])
        self.dropout = nn.Dropout(dropout_rate) if use_dropout else nn.Identity()
        self.fc = nn.Linear(dims[-1], num_classes)

    def get_config(self):
        return self.config

    def forward(self, x):
        if x.dim() == 5 and x.size(1) == 1:
            x = x.squeeze(1)
        self.reset_states()
        out_sum = None
        for t in range(self.T):
            x_t = x
            for peg, transformer, bn, mlp, lif in self.layers_trans:
                x_t = peg(x_t)
                y = x_t
                x_t = transformer(x_t)
                x_t = mlp(x_t) + y
                x_t = bn(x_t)
                x_t = lif(x_t)
            x_t = self.conv_last(x_t)
            if out_sum is None:
                out_sum = x_t
            else:
                out_sum = out_sum + x_t
        if self.accum_mode == 'mean':
            out = out_sum / self.T
        elif self.accum_mode == 'last':
            out = x_t
        else:
            out = out_sum
        out = self.gap(out)
        out = self.dropout(out)
        out = self.norm(out)
        return self.fc(out)

    def reset_states(self):
        def _reset(module):
            if hasattr(module, 'reset'):
                module.reset()
            else:
                for child in module.children():
                    _reset(child)
        _reset(self)

# -------------------- LIF 前置的 SNNGSC 模块 --------------------
class SNNGSCPre(nn.Module):
    """
    与原始 SNNGSC 区别：LIF 放置在卷积之前，输出为脉冲。
    无后置 LIF，直接返回卷积后的连续值。
    """
    def __init__(self, dim_in, dim_out, padding=1, num_groups=8,
                 lif_threshold=0.5, lif_tau=2.0, surrogate_grad='fast_sigmoid'):
        super().__init__()
        self.lif = LIFSpike(tau=lif_tau, threshold=lif_threshold,
                            surrogate_grad=surrogate_grad, return_spike=True)  # 输出脉冲
        self.gpwc = nn.Conv2d(dim_in, dim_out, groups=num_groups, kernel_size=1)
        self.gc = nn.Conv2d(dim_out, dim_out, kernel_size=3, groups=num_groups,
                            padding=padding, stride=1)
        self.bn1 = nn.BatchNorm2d(dim_out)
        self.bn2 = nn.BatchNorm2d(dim_out)

    def forward(self, x):
        x = self.lif(x)       # 脉冲化
        x = self.gpwc(x)
        x = self.bn1(x)
        x = self.gc(x)
        x = self.bn2(x)
        return x              # 连续值输出

    def reset(self):
        self.lif.reset()


# -------------------- 主模型（LIF 前置） --------------------
class SNNGSCViTPre(nn.Module):
    """完整模型，使用 SNNGSCPre 替换原 SNNGSC"""
    def __init__(
            self,
            *,
            num_classes,
            depth,
            heads,
            group_spatial_size,
            dropout=0.1,
            padding,
            dims,
            num_groups,
            T=8,
            lif_threshold=0.5,
            lif_tau=2.0,
            surrogate_grad='fast_sigmoid',
            accum_mode='sum',
            use_dropout=True,
            dropout_rate=2.0,
            use_pwc=True,
    ):
        super().__init__()
        self.config = {
            'num_classes': num_classes,
            'depth': depth,
            'heads': heads,
            'group_spatial_size': group_spatial_size,
            'dropout': dropout,
            'padding': padding,
            'dims': dims,
            'num_groups': num_groups,
            'T': T,
            'lif_threshold': lif_threshold,
            'lif_tau': lif_tau,
            'surrogate_grad': surrogate_grad,
            'accum_mode': accum_mode,
            'use_dropout': use_dropout,
            'dropout_rate': dropout_rate,
            'use_pwc': use_pwc,
            'lif_placement': 'pre',   # 标识
        }
        self.T = T
        self.accum_mode = accum_mode
        num_stages = len(depth)
        dim_pairs = tuple(zip(dims[:-1], dims[1:]))
        hyperparams_per_stage = [heads]
        hyperparams_per_stage = list(map(partial(cast_tuple, length=num_stages), hyperparams_per_stage))

        self.layers_trans = nn.ModuleList([])
        for ind, ((layer_dim_in, layer_dim), layer_depth, layer_heads, p, num_group, g_size) in enumerate(
                zip(dim_pairs, depth, *hyperparams_per_stage, padding, num_groups, group_spatial_size)):
            is_last = ind == (num_stages - 1)

            if use_pwc:
                mlp_or_pwc = nn.Conv2d(layer_dim, layer_dim, 1)
            else:
                expand = 4
                mlp_or_pwc = nn.Sequential(
                    nn.Conv2d(layer_dim, layer_dim * expand, 1),
                    nn.BatchNorm2d(layer_dim * expand),
                    LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False),
                    nn.Conv2d(layer_dim * expand, layer_dim, 1),
                    nn.BatchNorm2d(layer_dim)
                )

            self.layers_trans.append(nn.ModuleList([
                SNNGSCPre(layer_dim_in, layer_dim, p, num_group,
                          lif_threshold=lif_threshold, lif_tau=lif_tau,
                          surrogate_grad=surrogate_grad),
                ImprovedSNNTransformer(dim=layer_dim, depth=layer_depth, heads=layer_heads,
                                       group_size=g_size, dropout=dropout, norm_output=not is_last,
                                       lif_threshold=lif_threshold, lif_tau=lif_tau,
                                       surrogate_grad=surrogate_grad),
                nn.BatchNorm2d(layer_dim),
                mlp_or_pwc,
                LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False)
            ]))

        self.conv_last = nn.Sequential(
            nn.Conv2d(dims[-1], dims[-1] * 2, 3, padding=1),
            nn.BatchNorm2d(dims[-1] * 2),
            LIFSpike(tau=lif_tau, threshold=lif_threshold, surrogate_grad=surrogate_grad, return_spike=False),
            nn.Conv2d(dims[-1] * 2, dims[-1], 1)
        )
        self.gap = Reduce('b d h w -> b d', 'mean')
        self.norm = nn.LayerNorm(dims[-1])
        self.dropout = nn.Dropout(dropout_rate) if use_dropout else nn.Identity()
        self.fc = nn.Linear(dims[-1], num_classes)

    def get_config(self):
        return self.config

    def forward(self, x):
        if x.dim() == 5 and x.size(1) == 1:
            x = x.squeeze(1)
        self.reset_states()
        out_sum = None
        for t in range(self.T):
            x_t = x
            for peg, transformer, bn, mlp, lif in self.layers_trans:
                x_t = peg(x_t)
                y = x_t
                x_t = transformer(x_t)
                x_t = mlp(x_t) + y
                x_t = bn(x_t)
                x_t = lif(x_t)
            x_t = self.conv_last(x_t)
            if out_sum is None:
                out_sum = x_t
            else:
                out_sum = out_sum + x_t
        if self.accum_mode == 'mean':
            out = out_sum / self.T
        elif self.accum_mode == 'last':
            out = x_t
        else:
            out = out_sum
        out = self.gap(out)
        out = self.dropout(out)
        out = self.norm(out)
        return self.fc(out)

    def reset_states(self):
        def _reset(module):
            if hasattr(module, 'reset'):
                module.reset()
            else:
                for child in module.children():
                    _reset(child)
        _reset(self)


# -------------------- 工厂函数 --------------------
def snn_gscvit_spiking_pre(dataset, T=8, lif_threshold=0.5, lif_tau=2.0,
                           surrogate_grad='fast_sigmoid', accum_mode='sum',
                           use_dropout=True, input_channels=None, use_pwc=True):
    """
    LIF 前置版本的 SNN-GSCViT，用于消融实验。
    参数与原始 snn_gscvit_spiking 相同。
    """
    configs = {
        'sa': (16, 204, (1, 1, 1), [16, 16, 16]),
        'pu': (9, 103, (1, 1, 1), [16, 16, 16]),
        'whulk': (9, 270, (4, 4, 4), [16, 16, 16]),
        'whuhh': (22, 270, (4, 4, 4), [16, 16, 16]),
        'whuhc': (16, 274, (4, 4, 4), [16, 16, 16]),
        'hrl': (14, 176, (1, 1, 1), [16, 16, 16]),
        'flt': (10, 80, (1, 1, 1), [16, 16, 16]),
        'ksc': (13, 176, (1, 1, 1), [16, 16, 16]),
        'ip': (16, 200, (8, 8, 8), [16, 16, 16]),
        'hus': (15, 144, (1, 1, 1), [16, 16, 16]),
        'MUUFL': (11, 64, (1, 1, 1), [16, 16, 16]),
        'Trento': (6, 63, (1, 1, 1), [16, 16, 16]),
        'botswana': (14, 145, (1, 1, 1), [32, 32, 32]),
    }
    if dataset not in configs:
        raise ValueError(f"Unknown dataset: {dataset}")
    num_classes, _, heads, _ = configs[dataset]
    if input_channels is None:
        raise ValueError("input_channels must be provided.")

    num_groups = 8
    if input_channels % num_groups != 0:
        num_groups = 1

    dims = (input_channels, 128, 64)
    group_spatial_size = [4, 4, 4]

    model = SNNGSCViTPre(
        num_classes=num_classes,
        depth=(1, 1, 1),
        heads=heads,
        group_spatial_size=group_spatial_size,
        dropout=0.1,
        padding=[1, 1, 1],
        dims=dims,
        num_groups=[num_groups, num_groups, num_groups],
        T=T,
        lif_threshold=lif_threshold,
        lif_tau=lif_tau,
        surrogate_grad=surrogate_grad,
        accum_mode=accum_mode,
        use_dropout=use_dropout,
        dropout_rate=0.3,
        use_pwc=use_pwc,
    )
    return model
# -------------------- 模型工厂函数（默认使用改进版）--------------------
def snn_gscvit_spiking(dataset, T=8, lif_threshold=0.5, lif_tau=2.0,
                       surrogate_grad='fast_sigmoid', accum_mode='sum', use_dropout=True,
                       input_channels=None, use_pwc=True, improved=True):
    """
    默认 improved=True，使用改进版模型（更高精度、更快速度）
    """
    configs = {
        'sa': (16, 204, (1, 1, 1), [16, 16, 16]),
        'pu': (9, 103, (1, 1, 1), [16, 16, 16]),
        'whulk': (9, 270, (4, 4, 4), [16, 16, 16]),
        'whuhh': (22, 270, (4, 4, 4), [16, 16, 16]),
        'whuhc': (16, 274, (4, 4, 4), [16, 16, 16]),
        'hrl': (14, 176, (1, 1, 1), [16, 16, 16]),
        'flt': (10, 80, (1, 1, 1), [16, 16, 16]),
        'ksc': (13, 176, (1, 1, 1), [16, 16, 16]),
        #'ip': (16, 200, (1, 1, 1), [16, 16, 16]),
        'ip': (16, 200, (8, 8, 8), [16, 16, 16]),
        'hus': (15, 144, (1, 1, 1), [16, 16, 16]),
        'MUUFL': (11, 64, (1, 1, 1), [16, 16, 16]),
        'Trento': (6, 63, (1, 1, 1), [16, 16, 16]),
        'botswana': (14, 145, (1, 1, 1), [32, 32, 32]),
    }
    if dataset not in configs:
        raise ValueError(f"Unknown dataset: {dataset}")
    num_classes, _, heads, _ = configs[dataset]
    if input_channels is None:
        raise ValueError("input_channels must be provided when SC is removed.")

    num_groups = 8
    if input_channels % num_groups != 0:
        num_groups = 1

    dims = (input_channels, 128, 64)
    group_spatial_size = [4, 4, 4]

    if not improved:
        raise ValueError("Original SNNGSCViT is not supported. Please use improved=True (default).")

    ModelClass = SNNGSCViTImproved
    model = ModelClass(
        num_classes=num_classes,
        depth=(1, 1, 1),
        heads=heads,
        group_spatial_size=group_spatial_size,
        dropout=0.1,
        padding=[1, 1, 1],
        dims=dims,
        num_groups=[num_groups, num_groups, num_groups],
        T=T,
        lif_threshold=lif_threshold,
        lif_tau=lif_tau,
        surrogate_grad=surrogate_grad,
        accum_mode=accum_mode,
        use_dropout=use_dropout,
        dropout_rate=0.3,
        use_pwc=use_pwc,
    )
    return model


# 测试代码
if __name__ == '__main__':
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    img = torch.randn(1, 40, 8, 8).to(device)
    print("input shape:", img.shape)
    net = snn_gscvit_spiking(dataset='whulk', T=2, input_channels=40, use_pwc=True).to(device)
    output = net(img)
    print("output shape:", output.shape)
    flops, params = profile(net, inputs=(img,))
    print('params', params)
    print('flops', flops)