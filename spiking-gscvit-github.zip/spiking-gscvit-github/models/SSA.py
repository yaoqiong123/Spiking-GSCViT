import torch
import torch.nn as nn
import torch.cuda
class SSA(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0., sr_ratio=1):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."
        self.dim = dim
        self.num_heads = num_heads
        self.scale = qk_scale or (dim // num_heads) ** -0.5

        self.q_linear = nn.Linear(dim, dim, bias=qkv_bias)
        self.q_bn = nn.BatchNorm1d(dim)

        self.k_linear = nn.Linear(dim, dim, bias=qkv_bias)
        self.k_bn = nn.BatchNorm1d(dim)

        self.v_linear = nn.Linear(dim, dim, bias=qkv_bias)
        self.v_bn = nn.BatchNorm1d(dim)

        self.proj_linear = nn.Linear(dim, dim)
        self.proj_bn = nn.BatchNorm1d(dim)

        # Initialize learnable position embeddings
        self.position_embeddings = nn.Parameter(torch.randn(1, dim, 1))

    def forward(self, x):
        B, N, C = x.shape

        # Adjust the position embeddings to match the input dimensions and move to the same device as input
        if self.position_embeddings.shape[1] != N:
            self.position_embeddings = nn.Parameter(torch.randn(1, N, C).to(x.device))

        # Add position embeddings to input
        x_for_qkv = x + self.position_embeddings

        # Q pathway
        q = self.q_bn(self.q_linear(x_for_qkv).transpose(1, 2)).transpose(1, 2)
        q = q.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        # K pathway
        k = self.k_bn(self.k_linear(x_for_qkv).transpose(1, 2)).transpose(1, 2)
        k = k.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        # V pathway
        v = self.v_bn(self.v_linear(x_for_qkv).transpose(1, 2)).transpose(1, 2)
        v = v.reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)

        # Attention calculation
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        x = attn @ v
        x = x.permute(0, 2, 1, 3).contiguous().view(B, N, -1)

        # Projection
        x = self.proj_bn(self.proj_linear(x).transpose(1, 2)).transpose(1, 2)
        x = x.view(B, N, C)
        x = x + x_for_qkv

        # Reshape for image-like output (optional, depends on your task)
        H = W = int(N ** 0.5)
        x = x.reshape(B, C, H, W)
        return x

