import matplotlib.pyplot as plt
import numpy as np

plt.rcParams['pdf.fonttype'] = 42
plt.rcParams['ps.fonttype'] = 42
plt.rcParams['font.family'] = 'sans-serif'
plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']

# 参数
tau = 2.0
beta = 1 - 1/tau   # = 0.5
theta = 0.5
T = 10
I = [0.4, 0, 0.3, 0, 0.5, 0, 0.2, 0, 0.1, 0]

U = np.zeros(T)
S = np.zeros(T)
for t in range(T):
    if t == 0:
        U[t] = I[t]
    else:
        U[t] = beta * U[t-1] + I[t]
    if U[t] >= theta:
        S[t] = 1
        U[t] = U[t] - theta

# 创建图形，稍微增加高度以避免标签重叠
fig, ax = plt.subplots(figsize=(10, 4.5))

# 膜电位
ax.step(range(T), U, where='mid', linewidth=2, color='#0066CC', label='Membrane potential $U[t]$')

# 脉冲和重置点
for t in range(T):
    if S[t] == 1:
        ax.plot([t, t], [0, 1.2], color='#FF6600', linewidth=2)
        ax.text(t, 1.25, 'Spike', ha='center', fontsize=8, color='#FF6600')
        ax.plot(t, U[t], 'o', color='#CC0000', markersize=6)
        ax.text(t, U[t]-0.08, 'reset', ha='center', fontsize=8, color='#CC0000')

# 阈值线（只标 θ）
ax.axhline(y=theta, color='red', linestyle='--', linewidth=1.5, label=r'Threshold $\theta$')

# 坐标轴
ax.set_xlabel('Time step $t$', fontsize=12, labelpad=8)
ax.set_ylabel('Membrane potential $U[t]$', fontsize=12, labelpad=8)
ax.set_title('LIF Neuron Dynamics', fontsize=14, pad=15)

# 设置 x 轴刻度位置（在整数步中间）
ax.set_xticks(range(T))
ax.set_xticklabels([str(i) for i in range(T)])

ax.set_ylim(-0.1, 1.4)
ax.set_xlim(-0.5, T-0.5)

# 图例：包含膜电位、阈值，再加入时间常数信息
ax.legend(loc='upper right', fontsize=10)

# 在图形右上角(axes坐标)添加一个文本框，说明 τ 和 decay，不干扰主图
#props = dict(boxstyle='round', facecolor='white', alpha=0.8)
#ax.text(0.98, 0.98, r'$\tau = 2.0$, decay factor $1-1/\tau = 0.5$',
#        transform=ax.transAxes, fontsize=9,
#        verticalalignment='top', horizontalalignment='right',
#        bbox=props)

ax.grid(alpha=0.3)

plt.tight_layout()
plt.savefig('lif_neuron.eps', format='eps', bbox_inches='tight')
plt.savefig('lif_neuron.png', dpi=300, bbox_inches='tight')
print("已保存: lif_neuron.eps 和 lif_neuron.png")