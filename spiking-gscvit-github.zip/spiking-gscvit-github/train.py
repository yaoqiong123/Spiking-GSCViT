import os
import numpy as np
from tqdm import tqdm
import torch
from utils.utils import grouper, sliding_window, count_sliding_window

def train(network, optimizer, criterion, train_loader, val_loader, epoch, saving_path, device, scheduler=None):
    best_acc = -0.1
    losses = []

    for e in tqdm(range(1, epoch+1), desc=""):
        network.train()
        for batch_idx, (images, targets) in enumerate(train_loader):
            if hasattr(network, 'reset_states'):
                network.reset_states()

            images, targets = images.to(device), targets.to(device)

            # 对 AFSA 和 TGRS 去除多余的维度（从 [B, 1, C, H, W] -> [B, C, H, W]）
            if network.__class__.__name__ in ['AFSA', 'TGRS']:
                images = images.squeeze(1)

            optimizer.zero_grad()
            outputs = network(images)
            loss = criterion(outputs, targets)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(network.parameters(), max_norm=1.0)
            optimizer.step()
            losses.append(loss.item())

        if e % 10 == 0 or e == 1:
            mean_losses = np.mean(losses)
            train_info = "train at epoch {}/{}, loss={:.6f}"
            train_info = train_info.format(e, epoch, mean_losses)
            tqdm.write(train_info)
            losses = []
        else:
            losses = []

        # 验证并获取准确率和损失
        val_acc, val_loss = validation(network, val_loader, criterion, device)

        # 处理学习率调度器（兼容 ReduceLROnPlateau）
        if scheduler is not None:
            # 使用类名判断，避免 isinstance 可能的失效
            if scheduler.__class__.__name__ == 'ReduceLROnPlateau':
                scheduler.step(val_loss)
            else:
                scheduler.step()

        is_best = val_acc >= best_acc
        best_acc = max(val_acc, best_acc)
        save_checkpoint(network, is_best, saving_path, epoch=e, acc=best_acc)


def validation(network, val_loader, criterion, device):
    num_correct = 0.
    total_num = 0.
    total_loss = 0.
    network.eval()
    with torch.no_grad():
        for batch_idx, (images, targets) in enumerate(val_loader):
            if hasattr(network, 'reset_states'):
                network.reset_states()

            images, targets = images.to(device), targets.to(device)

            # 对 AFSA 和 TGRS 去除多余的维度
            if network.__class__.__name__ in ['AFSA', 'TGRS']:
                images = images.squeeze(1)

            outputs = network(images)
            loss = criterion(outputs, targets)
            total_loss += loss.item() * len(targets)
            _, predicted = torch.max(outputs, dim=1)
            num_correct += (predicted == targets).sum().item()
            total_num += len(targets)

    overall_acc = num_correct / total_num
    avg_loss = total_loss / total_num
    return overall_acc, avg_loss


def test(network, model_dir, image, patch_size, n_classes, device):
    network.load_state_dict(torch.load(model_dir + "/model_best.pth"))
    network.eval()

    batch_size = 128
    window_size = (patch_size, patch_size)
    image_w, image_h = image.shape[:2]
    pad_size = patch_size // 2

    # pad the image
    image = np.pad(image, ((pad_size, pad_size), (pad_size, pad_size), (0, 0)), mode='reflect')

    probs = np.zeros(image.shape[:2] + (n_classes,))

    iterations = count_sliding_window(image, window_size=window_size) // batch_size
    for batch in tqdm(grouper(batch_size, sliding_window(image, window_size=window_size)),
                      total=iterations,
                      desc="inference on the HSI"):
        with torch.no_grad():
            if hasattr(network, 'reset_states'):
                network.reset_states()

            data = [b[0] for b in batch]
            data = np.copy(data)
            data = data.transpose((0, 3, 1, 2))
            data = torch.from_numpy(data)

            model_name = network.__class__.__name__
            # 只有非 AFSA 且非 TGRS 的模型才增加维度
            if model_name not in ['AFSA', 'TGRS']:
                data = data.unsqueeze(1)

            indices = [b[1:] for b in batch]
            data = data.to(device)
            output = network(data)
            if isinstance(output, tuple):
                output = output[0]
            output = output.to('cpu').numpy()

            for (x, y, w, h), out in zip(indices, output):
                probs[x + w // 2, y + h // 2] += out

    return probs[pad_size:image_w + pad_size, pad_size:image_h + pad_size, :]


def save_checkpoint(network, is_best, saving_path, **kwargs):
    if not os.path.isdir(saving_path):
        os.makedirs(saving_path, exist_ok=True)

    if is_best:
        tqdm.write("epoch = {epoch}: best OA = {acc:.4f}".format(**kwargs))
        torch.save(network.state_dict(), os.path.join(saving_path, 'model_best.pth'))
    else:
        if kwargs['epoch'] % 10 == 0:
            torch.save(network.state_dict(), os.path.join(saving_path, 'model.pth'))