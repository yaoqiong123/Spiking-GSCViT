import argparse
import numpy as np
import torch.nn as nn
import torch.utils.data
from torchsummary import summary
from utils.dataset import load_mat_hsi, sample_gt, HSIDataset
from utils.utils import split_info_print, metrics, show_results
from utils.scheduler import load_scheduler
from models.get_model import get_model
from train import train, test
from utils.utils import Draw
import os
import datetime
import time
from sklearn.decomposition import PCA
from thop import profile

# 导入 LIFSpike 用于 SOPs 计算（需在 compute_sops 中使用）
from models.snn_gscvit import LIFSpike

# 全局变量，用于累计脉冲计数
global_spike_count = 0

def spike_hook(module, input, output):
    """钩子函数，直接读取 LIF 模块内部的 spike 属性来累计脉冲数"""
    global global_spike_count
    if isinstance(module, LIFSpike):
        if hasattr(module, 'spike') and module.spike is not None:
            global_spike_count += module.spike.sum().item()

def count_parameters(model):
    """计算模型的总参数量（包括权重和偏置）"""
    return sum(p.numel() for p in model.parameters())

def compute_sops(model, dummy_input, num_steps):
    """计算模型的SOPs（近似）"""
    global global_spike_count
    global_spike_count = 0

    hooks = []
    for module in model.modules():
        if isinstance(module, LIFSpike):
            hooks.append(module.register_forward_hook(spike_hook))

    with torch.no_grad():
        _ = model(dummy_input)

    for hook in hooks:
        hook.remove()

    total_params = count_parameters(model)
    sops = global_spike_count * total_params
    return sops, total_params


# ---------- 基于比例的采样函数 ----------
def ratio_sample_per_class(gt, ratio, seed):
    """
    对每个类别按比例采样训练、验证和测试样本。
    训练样本数 = max(1, floor(N * ratio))
    验证样本数 = max(1, floor(N * ratio))
    剩余为测试样本。
    若训练+验证 > N，则优先削减验证样本数。
    """
    np.random.seed(seed)
    num_classes = gt.max() + 1
    train_gt = np.full_like(gt, -1)
    val_gt = np.full_like(gt, -1)
    test_gt = np.full_like(gt, -1)

    for cls in range(num_classes):
        coords = np.argwhere(gt == cls)
        n_total = len(coords)
        if n_total == 0:
            continue

        # 计算训练和验证样本数
        train_n = max(1, int(np.floor(n_total * ratio)))
        val_n = max(1, int(np.floor(n_total * ratio)))

        # 若训练+验证超过总数，则从验证中扣除多余部分
        if train_n + val_n > n_total:
            val_n = n_total - train_n
            if val_n < 1:
                # 极端情况：总数太小，重新分配
                train_n = n_total // 2
                val_n = n_total - train_n
                if train_n == 0:
                    train_n = n_total
                    val_n = 0
        test_n = n_total - train_n - val_n

        np.random.shuffle(coords)
        train_coords = coords[:train_n]
        val_coords = coords[train_n:train_n + val_n]
        test_coords = coords[train_n + val_n:train_n + val_n + test_n]

        train_gt[train_coords[:, 0], train_coords[:, 1]] = cls
        val_gt[val_coords[:, 0], val_coords[:, 1]] = cls
        test_gt[test_coords[:, 0], test_coords[:, 1]] = cls

    return train_gt, val_gt, test_gt


def compute_class_counts(gt, num_classes):
    """返回每个类别的像素数量列表"""
    counts = []
    for i in range(num_classes):
        counts.append(np.sum(gt == i))
    return counts


# ---------- 保存实验结果的函数 ----------
def save_experiment_results(results, opts, labels, best_run_idx=None, flops=None, params=None, sops=None,
                            best_class_counts=None, model_config=None, num_bands=None, ratio=None):
    save_dir = "./results"
    os.makedirs(save_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{opts.model}_{opts.dataset_name}_{timestamp}.txt"
    filepath = os.path.join(save_dir, filename)

    lines = []
    lines.append("Experiment Configuration:")
    lines.append(f"model: {opts.model}")
    lines.append(f"dataset: {opts.dataset_name}")
    lines.append(f"patch_size: {opts.patch_size}")
    lines.append(f"batch_size: {opts.bs}")
    lines.append(f"epoch: {opts.epoch}")
    lines.append(f"device: {opts.device}")
    lines.append(f"num_run: {opts.num_run}")
    lines.append(f"draw: {opts.draw}")
    lines.append(f"T: {opts.T}")
    lines.append(f"tau: {opts.tau}")
    lines.append(f"threshold: {opts.threshold}")
    lines.append(f"ratio (train/val per class): {ratio}")   # 记录比例
    if num_bands is not None:
        lines.append(f"PCA components: {num_bands}")
    if flops is not None:
        lines.append(f"FLOPs: {flops:,} (MACs)")
    if params is not None:
        lines.append(f"Parameters: {params:,}")
    if sops is not None:
        lines.append(f"SOPs (approx): {sops:,} (Synaptic Operations)")

    if model_config is not None:
        lines.append("Model Configuration:")
        for key, value in model_config.items():
            lines.append(f"  {key}: {value}")
    lines.append("")

    if best_class_counts is not None and best_run_idx is not None:
        lines.append("Sample distribution of best run (class-wise):")
        lines.append("Class\tTrain\tVal\tTest\tTotal")
        for i, name in enumerate(labels):
            train_c = best_class_counts['train'][i]
            val_c = best_class_counts['val'][i]
            test_c = best_class_counts['test'][i]
            total = train_c + val_c + test_c
            lines.append(f"{name}\t{train_c}\t{val_c}\t{test_c}\t{total}")
        lines.append("")

    lines.append("Results per run:")
    for i, res in enumerate(results):
        base_line = f"Run {i+1}: OA={res['Accuracy']:.4f}, AA={res['AA']:.4f}, Kappa={res['Kappa']:.4f}"
        if 'train_time' in res and 'test_time' in res:
            base_line += f", TrainTime={res['train_time']:.2f}s, TestTime={res['test_time']:.2f}s"
        if best_run_idx is not None and i == best_run_idx:
            base_line += "  <-- Best OA"
        lines.append(base_line)

    if len(results) > 1:
        oa_list = [r['Accuracy'] for r in results]
        aa_list = [r['AA'] for r in results]
        kappa_list = [r['Kappa'] for r in results]
        oa_mean, oa_std = np.mean(oa_list), np.std(oa_list)
        aa_mean, aa_std = np.mean(aa_list), np.std(aa_list)
        kappa_mean, kappa_std = np.mean(kappa_list), np.std(kappa_list)
        lines.append("")
        lines.append("Aggregated results (mean ± std):")
        lines.append(f"OA: {oa_mean:.4f} ± {oa_std:.4f}")
        lines.append(f"AA: {aa_mean:.4f} ± {aa_std:.4f}")
        lines.append(f"Kappa: {kappa_mean:.4f} ± {kappa_std:.4f}")
        if 'train_time' in results[0]:
            train_times = [r['train_time'] for r in results]
            test_times = [r['test_time'] for r in results]
            lines.append(f"Avg Train Time: {np.mean(train_times):.2f} ± {np.std(train_times):.2f} s")
            lines.append(f"Avg Test Time: {np.mean(test_times):.2f} ± {np.std(test_times):.2f} s")

    if 'class acc' in results[0]:
        num_classes = len(results[0]['class acc'])
        class_acc_per_run = np.array([r['class acc'] for r in results])
        if len(results) > 1:
            class_mean = np.mean(class_acc_per_run, axis=0)
            class_std = np.std(class_acc_per_run, axis=0)
            lines.append("")
            lines.append("Class-wise accuracy (mean ± std):")
            for i, (mean, std) in enumerate(zip(class_mean, class_std)):
                class_name = labels[i] if i < len(labels) else f"Class {i+1}"
                lines.append(f"{class_name}: {mean:.4f} ± {std:.4f}")
        else:
            lines.append("")
            lines.append("Class-wise accuracy:")
            for i, acc in enumerate(results[0]['class acc']):
                class_name = labels[i] if i < len(labels) else f"Class {i+1}"
                lines.append(f"{class_name}: {acc:.4f}")

    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))

    print(f"\nResults saved to {filepath}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="run patch-based HSI classification")
    #snn_gscvit_fully_binary,snn_gscvit_spiking_pre,snn_gscvit_spiking,snn_gscvit_with_pwsa
    parser.add_argument("--model", type=str, default='snn_gscvit_spiking')
    parser.add_argument("--dataset_name", type=str, default="botswana")
    parser.add_argument("--dataset_dir", type=str, default="./datasets")
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--patch_size", type=int, default=8)
    parser.add_argument("--num_run", type=int, default=3)
    parser.add_argument("--epoch", type=int, default=100)
    parser.add_argument("--bs", type=int, default=128)
    # 新增 ratio 参数，用于控制训练和验证集的比例（各占 ratio）
    ##ip:0.05;sa:0.01;botswana:0.05;whulk0.002,whuhh:0.01，ksc：0.2,whuhc:0.01
    parser.add_argument("--ratio", type=float, default=0.05,
                        help="Proportion of training samples per class (and also validation), e.g., 0.1 means 10% for train and 10% for val, remaining for test")
    parser.add_argument("--draw", type=lambda x: x.lower() in ('true', 't', 'yes', '1'),
                        default=False, help="Whether to draw classification map")
    parser.add_argument("--T", type=int, default=16, help="Number of time steps for SNN")
    parser.add_argument("--tau", type=float, default=2.0,
                        help="Directly set membrane time constant tau (if provided, leak_mem is ignored)")
    #threshold,ip:0.15,sa,whulk:0.2,botswana:threshold=0.25,tau=2.5
    parser.add_argument("--threshold", type=float, default=0.2, help="Firing threshold for SNN")
    parser.add_argument("--use_pwc", type=lambda x: x.lower() in ('true', 't', 'yes', '1'),
                        default=True, help="Use PWC (True) or MLP (False) in transformer blocks")
    opts = parser.parse_args()

    # 检查 ratio 合理性，若大于0.5则自动降为0.5
    if opts.ratio > 0.5:
        print(f"Warning: ratio={opts.ratio} > 0.5, which would cause train+val > total. Setting ratio to 0.5.")
        opts.ratio = 0.5

    device = torch.device("cuda:{}".format(opts.device))

    print("experiments will run on GPU device {}".format(opts.device))
    print("model = {}".format(opts.model))
    print("dataset = {}".format(opts.dataset_name))
    print("dataset folder = {}".format(opts.dataset_dir))
    print("patch size = {}".format(opts.patch_size))
    print("batch size = {}".format(opts.bs))
    print("total epoch = {}".format(opts.epoch))
    print("draw = {}".format(opts.draw))
    print("T = {}".format(opts.T))
    print("tau = {}".format(opts.tau))
    print("threshold = {}".format(opts.threshold))
    print("use_pwc = {}".format(opts.use_pwc))
    print("ratio (train/val per class) = {}".format(opts.ratio))

    # load data
    image, gt, labels = load_mat_hsi(opts.dataset_name, opts.dataset_dir)

    # PCA降维到40（可调，这里记录的是40）
    h, w, c = image.shape
    image_reshaped = image.reshape(-1, c)
    pca = PCA(n_components=10, random_state=42)
    image_pca = pca.fit_transform(image_reshaped).reshape(h, w, -1)
    image = image_pca
    num_bands = image.shape[-1]
    print(f"PCA applied: original bands {c} -> {num_bands}")

    num_classes = len(labels)

    seeds = [202401, 202402, 202403, 202404, 202405, 202406, 202407, 202408, 202409, 202410]

    # 先用第一个种子计算一次样本分布（各类别数量），用于记录最佳运行的样本分布
    train_gt_temp, val_gt_temp, test_gt_temp = ratio_sample_per_class(gt, opts.ratio, seeds[0])
    train_counts = compute_class_counts(train_gt_temp, num_classes)
    val_counts = compute_class_counts(val_gt_temp, num_classes)
    test_counts = compute_class_counts(test_gt_temp, num_classes)
    best_class_counts = {
        'train': train_counts,
        'val': val_counts,
        'test': test_counts
    }

    results = []
    best_oa_per_run = []

    model_flops = None
    model_params = None
    model_sops = None
    model_config = None  # 用于存储模型配置

    for run in range(opts.num_run):
        np.random.seed(seeds[run])
        print("running an experiment with the {} model".format(opts.model))
        print("run {} / {}".format(run + 1, opts.num_run))

        train_gt, val_gt, test_gt = ratio_sample_per_class(gt, opts.ratio, seeds[run])

        train_set = HSIDataset(image, train_gt, patch_size=opts.patch_size, data_aug=True)
        val_set = HSIDataset(image, val_gt, patch_size=opts.patch_size, data_aug=False)

        train_loader = torch.utils.data.DataLoader(train_set, opts.bs, drop_last=False, shuffle=True)
        val_loader = torch.utils.data.DataLoader(val_set, opts.bs, drop_last=False, shuffle=False)

        # 构建模型，传入 use_pwc
        model = get_model(opts.model, opts.dataset_name, opts.patch_size,
                          num_bands=num_bands, T=opts.T,
                          tau=opts.tau,
                          threshold=opts.threshold,
                          num_classes=num_classes,
                          use_pwc=opts.use_pwc)   # 新增参数

        if run == 0:
            split_info_print(train_gt, val_gt, test_gt, labels)
            print("network information:")
            model = model.to(device)
            with torch.no_grad():
                summary(model, (num_bands, opts.patch_size, opts.patch_size))
                dummy_input = torch.randn(1, num_bands, opts.patch_size, opts.patch_size).to(device)
                flops, params = profile(model, inputs=(dummy_input,), verbose=False)
                model_flops = flops
                model_params = params
                print(f"FLOPs: {int(flops):,} MACs")
                print(f"Parameters: {int(params):,}")

                sops, _ = compute_sops(model, dummy_input, opts.T)
                model_sops = sops
                print(f"SOPs (approx): {int(sops):,} Synaptic Operations")

            # 动态获取模型配置
            if hasattr(model, 'get_config'):
                model_config = model.get_config()
            else:
                model_config = None

        model = model.to(device)
        optimizer, scheduler = load_scheduler(opts.model, model)

        # ========== 在第一次运行时从优化器中提取超参数并补充到 model_config ==========
        if run == 0:
            # 确保 model_config 是字典
            if model_config is None:
                model_config = {}
            # 从优化器中获取学习率和权重衰减
            lr = optimizer.param_groups[0]['lr']
            weight_decay = optimizer.param_groups[0].get('weight_decay', None)
            # 更新配置字典
            model_config.update({
                'learning_rate': lr,
                'weight_decay': weight_decay,
                'optimizer': type(optimizer).__name__,
            })
        # ==================================================================

        criterion = nn.CrossEntropyLoss()
        # 计算训练集的类别权重
        train_labels = train_gt[train_gt != -1]
        class_counts = np.bincount(train_labels, minlength=num_classes)
        class_weights = 1.0 / (class_counts + 1e-6)
        class_weights = class_weights / class_weights.sum() * num_classes
        class_weights = torch.tensor(class_weights, dtype=torch.float).to(device)
        criterion = nn.CrossEntropyLoss(weight=class_weights)

        model_dir = "./checkpoints/" + opts.model + '/' + opts.dataset_name + '/' + str(run)

        train_start = time.time()
        try:
            train(model, optimizer, criterion, train_loader, val_loader, opts.epoch, model_dir, device, scheduler)
        except KeyboardInterrupt:
            print('"ctrl+c" is pressed, the training is over')
        train_end = time.time()
        train_time = train_end - train_start

        test_start = time.time()
        probabilities = test(model, model_dir, image, opts.patch_size, num_classes, device)
        test_end = time.time()
        test_time = test_end - test_start

        prediction = np.argmax(probabilities, axis=-1)

        run_results = metrics(prediction, test_gt, n_classes=num_classes)
        run_results['train_time'] = train_time
        run_results['test_time'] = test_time

        results.append(run_results)
        show_results(run_results, label_values=labels)

        best_oa_per_run.append((run_results['Accuracy'], run))

        del model, train_set, train_loader, val_set, val_loader

    if opts.num_run > 1:
        show_results(results, label_values=labels, agregated=True)

    best_oa, best_run_idx = max(best_oa_per_run, key=lambda x: x[0])
    print(f"\nBest OA = {best_oa:.4f} achieved at run {best_run_idx+1}")

    if opts.draw:
        print("Loading best model and drawing classification map...")
        best_model = get_model(opts.model, opts.dataset_name, opts.patch_size,
                               num_bands=num_bands, T=opts.T,
                               num_classes=num_classes,
                               use_pwc=opts.use_pwc)   # 同样传入
        best_model = best_model.to(device)
        best_model_dir = "./checkpoints/" + opts.model + '/' + opts.dataset_name + '/' + str(best_run_idx)
        best_model.load_state_dict(torch.load(os.path.join(best_model_dir, 'model_best.pth')))
        best_model.eval()
        Draw(best_model, image, gt, opts.patch_size, opts.dataset_name, opts.model + "_best", num_classes)
    else:
        print("Drawing disabled (--draw=False).")

    # 保存结果，包含模型配置和 PCA 组件数，以及 ratio
    save_experiment_results(results, opts, labels, best_run_idx=best_run_idx,
                            flops=model_flops, params=model_params, sops=model_sops,
                            best_class_counts=best_class_counts,
                            model_config=model_config,
                            num_bands=num_bands,
                            ratio=opts.ratio)