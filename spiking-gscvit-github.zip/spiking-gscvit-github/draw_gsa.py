"""
GSA (Group-wise Self-Attention) Module Diagram
垂直布局重排：图例在最底部，LIF 在输出下方，互不重叠
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches

plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['font.size'] = 10

# 图形尺寸 (宽 14, 高 12)
fig, ax = plt.subplots(1, 1, figsize=(14, 12))
ax.set_xlim(0, 14)
ax.set_ylim(0, 12)
ax.set_aspect('equal')
ax.axis('off')

# 颜色
color_bg = '#F0F8FF'
color_step_bg = '#E6F2FF'
color_attn_bg = '#F0E6FF'
color_linear = '#0070C0'
color_split = '#00A0A0'
color_attn = '#FF9900'
color_lif = '#ED7D31'
color_input = '#E8E8E8'
color_text = '#333333'
color_white = '#FFFFFF'

# ========== 整体背景框 ==========
bg = patches.FancyBboxPatch((0.5, 0.5), 13, 11.2,
                             boxstyle="round,pad=0.02",
                             facecolor=color_bg,
                             edgecolor='#0066CC',
                             linewidth=2)
ax.add_patch(bg)
ax.text(7, 11.5, "Group-wise Self-Attention (GSA) Module",
        ha='center', va='center', fontsize=14, fontweight='bold', color='#0066CC')

# ========== 输入 ==========
input_box = patches.FancyBboxPatch((5.5, 9.8), 2.8, 0.7,
                                    boxstyle="round,pad=0.05",
                                    facecolor=color_input,
                                    edgecolor='#666666',
                                    linewidth=1.5)
ax.add_patch(input_box)
ax.text(6.9, 10.15, "Input Feature Map", ha='center', va='center',
        fontsize=11, fontweight='bold', color=color_text)
ax.text(6.9, 9.95, "X ∈ ℝ^{B×C×H×W} (membrane)", ha='center', va='center',
        fontsize=9, color='#666666')

# 箭头：输入 → Step 1
ax.annotate('', xy=(2.8, 8.8), xytext=(6.9, 9.6),
            arrowprops=dict(arrowstyle='->', lw=1.5, color='black'))

# ========== Step 1: 分组 ==========
step1_bg = patches.FancyBboxPatch((1.0, 7.2), 3.6, 2.0,
                                   boxstyle="round,pad=0.05",
                                   facecolor=color_step_bg,
                                   edgecolor='#0066CC',
                                   linewidth=1)
ax.add_patch(step1_bg)
ax.text(2.8, 8.9, "Step 1: Spatial Grouping", ha='center', va='center',
        fontsize=10, fontweight='bold', color='#0066CC')

split_box = patches.FancyBboxPatch((1.4, 7.8), 2.8, 0.6,
                                    boxstyle="round,pad=0.05",
                                    facecolor=color_split,
                                    edgecolor='#008080',
                                    linewidth=1.5)
ax.add_patch(split_box)
ax.text(2.8, 8.1, "Split into Groups", ha='center', va='center',
        fontsize=10, fontweight='bold', color=color_white)
ax.text(2.8, 7.85, "(M×M, N = HW/M²)", ha='center', va='center',
        fontsize=8, color=color_white)

token_box = patches.FancyBboxPatch((1.4, 7.2), 2.8, 0.5,
                                    boxstyle="round,pad=0.05",
                                    facecolor=color_split,
                                    edgecolor='#008080',
                                    linewidth=1.5)
ax.add_patch(token_box)
ax.text(2.8, 7.45, "Learnable Group Token", ha='center', va='center',
        fontsize=9, fontweight='bold', color=color_white)
ax.text(2.8, 7.25, "g ∈ ℝ^C", ha='center', va='center',
        fontsize=8, color=color_white)

# ========== Step 2: 线性投影 ==========
step2_bg = patches.FancyBboxPatch((5.2, 7.2), 3.6, 2.0,
                                   boxstyle="round,pad=0.05",
                                   facecolor=color_step_bg,
                                   edgecolor='#0066CC',
                                   linewidth=1)
ax.add_patch(step2_bg)
ax.text(7.0, 8.9, "Step 2: Linear Projections", ha='center', va='center',
        fontsize=10, fontweight='bold', color='#0066CC')

linear_box = patches.FancyBboxPatch((5.6, 7.8), 2.8, 0.6,
                                     boxstyle="round,pad=0.05",
                                     facecolor=color_linear,
                                     edgecolor='#0050A0',
                                     linewidth=1.5)
ax.add_patch(linear_box)
ax.text(7.0, 8.1, "Linear Projections", ha='center', va='center',
        fontsize=10, fontweight='bold', color=color_white)
ax.text(7.0, 7.85, "W_Q, W_K, W_V ∈ ℝ^{C×C}", ha='center', va='center',
        fontsize=8, color=color_white)
ax.text(7.0, 7.65, "Q, K, V are membrane potentials", ha='center', va='center',
        fontsize=8, color='#0066CC')

# 箭头：Step 1 → Step 2
ax.annotate('', xy=(5.2, 8.1), xytext=(4.6, 8.1),
            arrowprops=dict(arrowstyle='->', lw=1.5, color='black'))

# ========== Step 3: 多头注意力 ==========
step3_bg = patches.FancyBboxPatch((1.0, 3.8), 10.0, 2.8,
                                   boxstyle="round,pad=0.05",
                                   facecolor=color_attn_bg,
                                   edgecolor='#800080',
                                   linewidth=1)
ax.add_patch(step3_bg)
ax.text(6.0, 6.3, "Step 3: Multi-Head Attention", ha='center', va='center',
        fontsize=10, fontweight='bold', color='#800080')

split_heads = patches.FancyBboxPatch((1.4, 5.4), 2.0, 0.6,
                                      boxstyle="round,pad=0.05",
                                      facecolor=color_split,
                                      edgecolor='#008080',
                                      linewidth=1.5)
ax.add_patch(split_heads)
ax.text(2.4, 5.7, "Split into Heads", ha='center', va='center',
        fontsize=9, fontweight='bold', color=color_white)
ax.text(2.4, 5.45, "(h heads, dim = C/h)", ha='center', va='center',
        fontsize=7, color=color_white)

q_box = patches.FancyBboxPatch((3.8, 4.8), 1.2, 0.7,
                                boxstyle="round,pad=0.05",
                                facecolor='#800080',
                                edgecolor='#600060',
                                linewidth=1.5)
ax.add_patch(q_box)
ax.text(4.4, 5.15, "Q", ha='center', va='center',
        fontsize=12, fontweight='bold', color=color_white)
ax.text(4.4, 4.85, "membrane", ha='center', va='center',
        fontsize=7, color=color_white)

k_box = patches.FancyBboxPatch((5.3, 4.8), 1.2, 0.7,
                                boxstyle="round,pad=0.05",
                                facecolor='#800080',
                                edgecolor='#600060',
                                linewidth=1.5)
ax.add_patch(k_box)
ax.text(5.9, 5.15, "K", ha='center', va='center',
        fontsize=12, fontweight='bold', color=color_white)
ax.text(5.9, 4.85, "membrane", ha='center', va='center',
        fontsize=7, color=color_white)

v_box = patches.FancyBboxPatch((6.8, 4.8), 1.2, 0.7,
                                boxstyle="round,pad=0.05",
                                facecolor='#800080',
                                edgecolor='#600060',
                                linewidth=1.5)
ax.add_patch(v_box)
ax.text(7.4, 5.15, "V", ha='center', va='center',
        fontsize=12, fontweight='bold', color=color_white)
ax.text(7.4, 4.85, "membrane", ha='center', va='center',
        fontsize=7, color=color_white)

# 箭头：线性 → 分头
ax.annotate('', xy=(1.4, 5.7), xytext=(5.6, 6.0),
            arrowprops=dict(arrowstyle='->', lw=1.5, color='black'))

ax.annotate('', xy=(3.8, 5.15), xytext=(2.4, 5.4),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))
ax.annotate('', xy=(5.3, 5.15), xytext=(2.8, 5.4),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))
ax.annotate('', xy=(6.8, 5.15), xytext=(3.2, 5.4),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))

# Q·K^T
qkt_box = patches.FancyBboxPatch((3.8, 4.0), 1.4, 0.5,
                                  boxstyle="round,pad=0.05",
                                  facecolor=color_attn,
                                  edgecolor='#CC7700',
                                  linewidth=1.5)
ax.add_patch(qkt_box)
ax.text(4.5, 4.25, "Q·Kᵀ", ha='center', va='center',
        fontsize=10, fontweight='bold', color=color_white)

soft_box = patches.FancyBboxPatch((5.5, 4.0), 1.5, 0.5,
                                   boxstyle="round,pad=0.05",
                                   facecolor=color_attn,
                                   edgecolor='#CC7700',
                                   linewidth=1.5)
ax.add_patch(soft_box)
ax.text(6.25, 4.25, "Scale+Softmax", ha='center', va='center',
        fontsize=9, fontweight='bold', color=color_white)
ax.text(6.25, 4.05, "(× α_in / √d)", ha='center', va='center',
        fontsize=7, color=color_white)

ax.annotate('', xy=(3.8, 4.25), xytext=(4.4, 4.8),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))
ax.annotate('', xy=(5.3, 4.25), xytext=(5.9, 4.8),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))
ax.annotate('', xy=(5.5, 4.25), xytext=(5.2, 4.25),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))

multv_box = patches.FancyBboxPatch((7.3, 4.0), 1.2, 0.5,
                                    boxstyle="round,pad=0.05",
                                    facecolor=color_attn,
                                    edgecolor='#CC7700',
                                    linewidth=1.5)
ax.add_patch(multv_box)
ax.text(7.9, 4.25, "× V", ha='center', va='center',
        fontsize=10, fontweight='bold', color=color_white)

ax.annotate('', xy=(7.3, 4.25), xytext=(7.0, 4.25),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))
ax.annotate('', xy=(7.3, 4.25), xytext=(7.4, 4.8),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))

concat_box = patches.FancyBboxPatch((7.3, 3.2), 1.4, 0.5,
                                     boxstyle="round,pad=0.05",
                                     facecolor=color_split,
                                     edgecolor='#008080',
                                     linewidth=1.5)
ax.add_patch(concat_box)
ax.text(8.0, 3.45, "Concatenate", ha='center', va='center',
        fontsize=9, fontweight='bold', color=color_white)

ax.annotate('', xy=(7.9, 3.7), xytext=(7.9, 4.0),
            arrowprops=dict(arrowstyle='->', lw=1.0, color='black'))

# ========== Output 和 LIF ==========
output_box = patches.FancyBboxPatch((5.5, 2.0), 2.8, 0.7,
                                     boxstyle="round,pad=0.05",
                                     facecolor=color_input,
                                     edgecolor='#666666',
                                     linewidth=1.5)
ax.add_patch(output_box)
ax.text(6.9, 2.35, "Output", ha='center', va='center',
        fontsize=11, fontweight='bold', color=color_text)
ax.text(6.9, 2.15, "(membrane, B×C×H×W)", ha='center', va='center',
        fontsize=8, color='#666666')

ax.annotate('', xy=(6.9, 2.7), xytext=(7.1, 3.2),
            arrowprops=dict(arrowstyle='->', lw=1.5, color='black'))

lif_box = patches.FancyBboxPatch((5.5, 1.1), 2.8, 0.7,
                                  boxstyle="round,pad=0.05",
                                  facecolor=color_lif,
                                  edgecolor='#C06020',
                                  linewidth=1.5)
ax.add_patch(lif_box)
ax.text(6.9, 1.45, "LIF (Spike Mode)", ha='center', va='center',
        fontsize=10, fontweight='bold', color=color_white)
ax.text(6.9, 1.25, "→ binary spikes", ha='center', va='center',
        fontsize=8, color=color_white)

ax.annotate('', xy=(6.9, 1.8), xytext=(6.9, 2.0),
            arrowprops=dict(arrowstyle='->', lw=1.5, color='black'))

# ========== 图例（单独放在最底部，不重叠）==========
legend_bg = patches.FancyBboxPatch((1.0, 0.1), 8.0, 0.9,
                                    boxstyle="round,pad=0.05",
                                    facecolor='#FFFFFF',
                                    edgecolor='#CCCCCC',
                                    linewidth=1)
ax.add_patch(legend_bg)
ax.text(1.2, 0.55, "Legend:", ha='left', va='center',
        fontsize=9, fontweight='bold', color=color_text)

legend_items = [
    (1.8, 0.4, 0.9, 0.28, color_linear, "Linear/Proj"),
    (2.9, 0.4, 0.8, 0.28, color_attn, "Attention"),
    (3.9, 0.4, 0.5, 0.28, color_lif, "LIF"),
    (4.6, 0.4, 0.8, 0.28, color_input, "Membrane"),
    (5.6, 0.4, 0.8, 0.28, color_split, "Split/Concat"),
]

for x, y, w, h, color, label in legend_items:
    box = patches.FancyBboxPatch((x, y), w, h,
                                  boxstyle="round,pad=0.02",
                                  facecolor=color,
                                  edgecolor='gray',
                                  linewidth=0.5)
    ax.add_patch(box)
    ax.text(x + w/2, y + h/2, label, ha='center', va='center',
            fontsize=8, color='white' if color != color_input else 'black')

# 保存
plt.tight_layout()
plt.savefig('gsa_module_final.pdf', dpi=300, bbox_inches='tight', facecolor='white')
plt.savefig('gsa_module_final.png', dpi=300, bbox_inches='tight', facecolor='white')
print("图片已保存: gsa_module_final.pdf 和 gsa_module_final.png")